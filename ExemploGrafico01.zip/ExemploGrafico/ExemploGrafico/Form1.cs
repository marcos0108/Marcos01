﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ExemploGrafico
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Grafico_Click(object sender, EventArgs e)
        {

        }

        private void Form1_Load(object sender, EventArgs e)
        {
            // TODO: esta linha de código carrega dados na tabela 'dbProdutosDataSet4.tbProdutos'. Você pode movê-la ou removê-la conforme necessário.
            this.tbProdutosTableAdapter1.Fill(this.dbProdutosDataSet4.tbProdutos);
            // TODO: esta linha de código carrega dados na tabela 'dbProdutosDataSet2.tbProdutos'. Você pode movê-la ou removê-la conforme necessário.
            this.tbProdutosTableAdapter.Fill(this.dbProdutosDataSet2.tbProdutos);

        }

        private void tbProdutosBindingSource_CurrentChanged(object sender, EventArgs e)
        {

        }
    }
}
