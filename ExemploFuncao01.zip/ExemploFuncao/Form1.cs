﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Aula_20200927
{
	public partial class Form1 : Form
	{
		public Form1()
		{
			InitializeComponent();
		}

		private void btnSoma_Click(object sender, EventArgs e)
		{
			string strConexao = "";
			string Query = "";
			string RetornoFuncao = "";
			SqlConnection conexao = null;
			SqlCommand comando = null;

			try
			{
				strConexao = ConfigurationManager.ConnectionStrings["MATEMATICA"].ConnectionString;

				Query = "SELECT DBO.UFN_SOMA(@NUMERO1, @NUMERO2)";
				
				conexao = new SqlConnection(strConexao);
				comando = new SqlCommand(Query, conexao);

				SqlParameter Numero1 =
				   new SqlParameter("@NUMERO1", SqlDbType.Int);

				Numero1.Value =
					int.Parse(txtNumero1.Text);
				comando.Parameters.Add(Numero1);

				SqlParameter Numero2 =
				   new SqlParameter("@NUMERO2", SqlDbType.Int);

				Numero2.Value =
					int.Parse(txtNumero2.Text);
				comando.Parameters.Add(Numero2);

				conexao.Open();

				RetornoFuncao =
					comando.ExecuteScalar().ToString();

				txtResultado.Text = RetornoFuncao;
			}
			catch (Exception ex)
			{
				string err = ex.Message;
				err += " !!!";
				MessageBox.Show(err);
			}
			finally
			{
				if (conexao != null)
					conexao.Close();
			}
		}

		private void btnSubtracao_Click(object sender, EventArgs e)
		{
			string strConexao = "";
			string Query = "";
			string RetornoFuncao = "";
			SqlConnection conexao = null;
			SqlCommand comando = null;

			try
			{
				strConexao = ConfigurationManager.ConnectionStrings["MATEMATICA"].ConnectionString;

				Query = "SELECT DBO.UFN_SUBTRACAO(@NUMERO1, @NUMERO2)";

				conexao = new SqlConnection(strConexao);
				comando = new SqlCommand(Query, conexao);

				// Para adicionar parametros em funções no SQL Server
				SqlParameter Numero1 =
				   new SqlParameter("@NUMERO1", SqlDbType.Int);

				Numero1.Value =
					int.Parse(txtNumero1.Text);
				comando.Parameters.Add(Numero1);

				SqlParameter Numero2 =
				   new SqlParameter("@NUMERO2", SqlDbType.Int);

				Numero2.Value =
					int.Parse(txtNumero2.Text);
				comando.Parameters.Add(Numero2);

				conexao.Open();

				// Para chamar uma função usamos ExecuteScalar
				RetornoFuncao =
					comando.ExecuteScalar().ToString();

				txtResultado.Text = RetornoFuncao;
			}
			catch (Exception ex)
			{
				string err = ex.Message;
				err += " !!!";
				MessageBox.Show(err);
			}
			finally
			{
				if (conexao != null)
					conexao.Close();
			}
		}

		private void btnMultiplicacao_Click(object sender, EventArgs e)
		{
			string strConexao = "";
			string Query = "";
			string RetornoFuncao = "";
			SqlConnection conexao = null;
			SqlCommand comando = null;

			try
			{
				strConexao = ConfigurationManager.ConnectionStrings["MATEMATICA"].ConnectionString;

				Query = "SELECT DBO.UFN_MULTIPLICACAO(@NUMERO1, @NUMERO2)";

				conexao = new SqlConnection(strConexao);
				comando = new SqlCommand(Query, conexao);

				SqlParameter Numero1 =
				   new SqlParameter("@NUMERO1", SqlDbType.Int);

				Numero1.Value =
					int.Parse(txtNumero1.Text);
				comando.Parameters.Add(Numero1);

				SqlParameter Numero2 =
				   new SqlParameter("@NUMERO2", SqlDbType.Int);

				Numero2.Value =
					int.Parse(txtNumero2.Text);
				comando.Parameters.Add(Numero2);

				conexao.Open();

				RetornoFuncao =
					comando.ExecuteScalar().ToString();

				txtResultado.Text = RetornoFuncao;
			}
			catch (Exception ex)
			{
				string err = ex.Message;
				err += " !!!";
				MessageBox.Show(err);
			}
			finally
			{
				if (conexao != null)
					conexao.Close();
			}
		}

		private void btnDivisao_Click(object sender, EventArgs e)
		{
			string strConexao = "";
			string Query = "";
			string RetornoFuncao = "";
			SqlConnection conexao = null;
			SqlCommand comando = null;

			try
			{
				strConexao = ConfigurationManager.ConnectionStrings["MATEMATICA"].ConnectionString;

				Query = "SELECT DBO.UFN_DIVISAO(@NUMERO1, @NUMERO2)";

				conexao = new SqlConnection(strConexao);
				comando = new SqlCommand(Query, conexao);

				SqlParameter Numero1 =
				   new SqlParameter("@NUMERO1", SqlDbType.Int);

				Numero1.Value =
					int.Parse(txtNumero1.Text);
				comando.Parameters.Add(Numero1);

				SqlParameter Numero2 =
				   new SqlParameter("@NUMERO2", SqlDbType.Int);

				Numero2.Value =
					int.Parse(txtNumero2.Text);
				comando.Parameters.Add(Numero2);

				conexao.Open();

				RetornoFuncao =
					comando.ExecuteScalar().ToString();

				txtResultado.Text = RetornoFuncao;
			}
			catch (Exception ex)
			{
				string err = ex.Message;
				err += " !!!";
				MessageBox.Show(err);
			}
			finally
			{
				if (conexao != null)
					conexao.Close();
			}
		}
	}
}
