﻿
namespace Aula_20200927
{
	partial class Form1
	{
		/// <summary>
		/// Variável de designer necessária.
		/// </summary>
		private System.ComponentModel.IContainer components = null;

		/// <summary>
		/// Limpar os recursos que estão sendo usados.
		/// </summary>
		/// <param name="disposing">true se for necessário descartar os recursos gerenciados; caso contrário, false.</param>
		protected override void Dispose(bool disposing)
		{
			if (disposing && (components != null))
			{
				components.Dispose();
			}
			base.Dispose(disposing);
		}

		#region Código gerado pelo Windows Form Designer

		/// <summary>
		/// Método necessário para suporte ao Designer - não modifique 
		/// o conteúdo deste método com o editor de código.
		/// </summary>
		private void InitializeComponent()
		{
			this.txtNumero1 = new System.Windows.Forms.TextBox();
			this.txtNumero2 = new System.Windows.Forms.TextBox();
			this.lblNumero1 = new System.Windows.Forms.Label();
			this.lblNumero2 = new System.Windows.Forms.Label();
			this.btnSoma = new System.Windows.Forms.Button();
			this.txtResultado = new System.Windows.Forms.TextBox();
			this.btnSubtracao = new System.Windows.Forms.Button();
			this.btnMultiplicacao = new System.Windows.Forms.Button();
			this.btnDivisao = new System.Windows.Forms.Button();
			this.SuspendLayout();
			// 
			// txtNumero1
			// 
			this.txtNumero1.Location = new System.Drawing.Point(121, 54);
			this.txtNumero1.Name = "txtNumero1";
			this.txtNumero1.Size = new System.Drawing.Size(100, 20);
			this.txtNumero1.TabIndex = 0;
			// 
			// txtNumero2
			// 
			this.txtNumero2.Location = new System.Drawing.Point(121, 80);
			this.txtNumero2.Name = "txtNumero2";
			this.txtNumero2.Size = new System.Drawing.Size(100, 20);
			this.txtNumero2.TabIndex = 0;
			// 
			// lblNumero1
			// 
			this.lblNumero1.AutoSize = true;
			this.lblNumero1.Location = new System.Drawing.Point(56, 60);
			this.lblNumero1.Name = "lblNumero1";
			this.lblNumero1.Size = new System.Drawing.Size(50, 13);
			this.lblNumero1.TabIndex = 1;
			this.lblNumero1.Text = "Numero1";
			// 
			// lblNumero2
			// 
			this.lblNumero2.AutoSize = true;
			this.lblNumero2.Location = new System.Drawing.Point(56, 87);
			this.lblNumero2.Name = "lblNumero2";
			this.lblNumero2.Size = new System.Drawing.Size(50, 13);
			this.lblNumero2.TabIndex = 1;
			this.lblNumero2.Text = "Numero2";
			// 
			// btnSoma
			// 
			this.btnSoma.Location = new System.Drawing.Point(371, 54);
			this.btnSoma.Name = "btnSoma";
			this.btnSoma.Size = new System.Drawing.Size(100, 42);
			this.btnSoma.TabIndex = 2;
			this.btnSoma.Text = "SOMA";
			this.btnSoma.UseVisualStyleBackColor = true;
			this.btnSoma.Click += new System.EventHandler(this.btnSoma_Click);
			// 
			// txtResultado
			// 
			this.txtResultado.Enabled = false;
			this.txtResultado.Font = new System.Drawing.Font("Microsoft Sans Serif", 30F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.txtResultado.Location = new System.Drawing.Point(243, 54);
			this.txtResultado.Multiline = true;
			this.txtResultado.Name = "txtResultado";
			this.txtResultado.Size = new System.Drawing.Size(100, 46);
			this.txtResultado.TabIndex = 3;
			this.txtResultado.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
			// 
			// btnSubtracao
			// 
			this.btnSubtracao.Location = new System.Drawing.Point(477, 54);
			this.btnSubtracao.Name = "btnSubtracao";
			this.btnSubtracao.Size = new System.Drawing.Size(100, 42);
			this.btnSubtracao.TabIndex = 2;
			this.btnSubtracao.Text = "SUBTRAÇÃO";
			this.btnSubtracao.UseVisualStyleBackColor = true;
			this.btnSubtracao.Click += new System.EventHandler(this.btnSubtracao_Click);
			// 
			// btnMultiplicacao
			// 
			this.btnMultiplicacao.Location = new System.Drawing.Point(371, 117);
			this.btnMultiplicacao.Name = "btnMultiplicacao";
			this.btnMultiplicacao.Size = new System.Drawing.Size(100, 42);
			this.btnMultiplicacao.TabIndex = 2;
			this.btnMultiplicacao.Text = "MULTIPLICACAO";
			this.btnMultiplicacao.UseVisualStyleBackColor = true;
			this.btnMultiplicacao.Click += new System.EventHandler(this.btnMultiplicacao_Click);
			// 
			// btnDivisao
			// 
			this.btnDivisao.Location = new System.Drawing.Point(477, 117);
			this.btnDivisao.Name = "btnDivisao";
			this.btnDivisao.Size = new System.Drawing.Size(100, 42);
			this.btnDivisao.TabIndex = 2;
			this.btnDivisao.Text = "DIVISAO";
			this.btnDivisao.UseVisualStyleBackColor = true;
			this.btnDivisao.Click += new System.EventHandler(this.btnDivisao_Click);
			// 
			// Form1
			// 
			this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
			this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
			this.ClientSize = new System.Drawing.Size(691, 309);
			this.Controls.Add(this.txtResultado);
			this.Controls.Add(this.btnSubtracao);
			this.Controls.Add(this.btnDivisao);
			this.Controls.Add(this.btnMultiplicacao);
			this.Controls.Add(this.btnSoma);
			this.Controls.Add(this.lblNumero2);
			this.Controls.Add(this.lblNumero1);
			this.Controls.Add(this.txtNumero2);
			this.Controls.Add(this.txtNumero1);
			this.Name = "Form1";
			this.Text = "Form1";
			this.ResumeLayout(false);
			this.PerformLayout();

		}

		#endregion

		private System.Windows.Forms.TextBox txtNumero1;
		private System.Windows.Forms.TextBox txtNumero2;
		private System.Windows.Forms.Label lblNumero1;
		private System.Windows.Forms.Label lblNumero2;
		private System.Windows.Forms.Button btnSoma;
		private System.Windows.Forms.TextBox txtResultado;
		private System.Windows.Forms.Button btnSubtracao;
		private System.Windows.Forms.Button btnMultiplicacao;
		private System.Windows.Forms.Button btnDivisao;
	}
}

